create PROCEDURE describesql(sqlquery in VARCHAR2) 
is
cur PLS_INTEGER := DBMS_SQL.OPEN_CURSOR;
cols DBMS_SQL.DESC_TAB;
ncols PLS_INTEGER;
BEGIN
--PARSE QUERY
DBMS_SQL.PARSE(cur, sqlquery,DBMS_SQL.NATIVE);
DBMS_SQL.DESCRIBE_COLUMNS(cur, ncols,cols);
for colind in 1 .. ncols
LOOP 
DBMS_OUTPUT.PUT_LINE(cols(colind).col_value);
END LOOP;
DBMS_SQL.CLOSE_CURSOR(cur);
END;
/

