create view V_ASSIGNEE_GROUP as
  select ASSIGNMENT as GROUP_NAME, SUBGROUP as SUBGROUP from SM_OP.TSISUBGROUPRELATIONM1
WHERE
      ASSIGNMENT IN
      (SELECT
          NAME
       FROM
          SM_OP.ASSIGNMENTB25305B0A1
          group by name
    -- Hier bitte den Schwellwert fuer die Anzahl der User in einer Gruppe angeben (mind. 5 User)
       HAVING count(NAME) >= 5)
    UNION
    SELECT
        'Anwenderspezifisch' AS GROUP_NAME,
       null AS SUBGROUP
    FROM
       DUAL
       UNION
          --  union mit allen Bearbeitergruppen, die keine Subgruppen haben und mehr als 5 User
   select distinct (NAME) as GROUP_NAME, null as SUPGROUP from SM_OP.ASSIGNMENTB25305B0A1
WHERE
name not in (select ASSIGNMENT from SM_OP.TSISUBGROUPRELATIONM1)
and name in 
      (SELECT
          NAME
       FROM
          SM_OP.ASSIGNMENTB25305B0A1
          group by name
    -- Hier bitte den Schwellwert fuer die Anzahl der User in einer Gruppe angeben
       HAVING count(NAME) >= 5)
/

