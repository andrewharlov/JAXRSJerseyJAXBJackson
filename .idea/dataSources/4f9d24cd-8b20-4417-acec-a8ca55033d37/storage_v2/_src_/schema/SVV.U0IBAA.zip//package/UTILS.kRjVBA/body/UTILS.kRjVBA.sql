create PACKAGE BODY         utils
AS

   FUNCTION oradate2sv (oradate IN DATE)
      RETURN NUMBER
   AS
      sv_date    INTEGER;
      gmt_date    DATE;
      start_dst   DATE;
      end_dst     DATE;
      sunday      VARCHAR2 (255);
      c_sunday    ref_cursor;
   BEGIN
      --  BEI LEEREM INPUT WIRD NULL ZURUECKGEGEBEN.
      IF oradate IS NULL THEN
         RETURN NULL;
      END IF;

      --  UMRECHNEN IN SEKUNDEN NACH DEM 01.01.1970 00:00:00 GMT
      sv_date :=
         TO_NUMBER (TRUNC (oradate, 'dd') - TO_DATE ('01.01.1970 00:00:00', 'dd.mm.yyyy hh24:mi:ss')) * 86400 +
         TO_NUMBER (TO_CHAR (oradate, 'hh24')) * 3600                                                       +
         TO_NUMBER (TO_CHAR (oradate, 'mi')) * 60                                                           +
         TO_NUMBER (TO_CHAR (oradate, 'ss'));
      RETURN sv_date;
   END;

END utils;
/

