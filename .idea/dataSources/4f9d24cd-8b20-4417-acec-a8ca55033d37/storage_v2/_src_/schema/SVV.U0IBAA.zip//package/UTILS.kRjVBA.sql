create PACKAGE         utils AUTHID DEFINER
AS

   TYPE ref_cursor IS REF CURSOR;

   FUNCTION oradate2sv (oradate IN DATE)
      RETURN NUMBER;

END utils;
/

